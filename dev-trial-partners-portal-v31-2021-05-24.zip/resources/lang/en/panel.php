<?php

return [
    'site_title' => 'Trial Partners Portal V3.1',
];
